import { Component } from '@angular/core';

@Component({
  selector: 'app-about-as',
   standalone: true,
  imports: [],
  templateUrl: './about-as.html',
})
export class AboutAs {

}
