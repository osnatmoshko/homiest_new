import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProductService } from '../services/product';
import { Product } from '../models/product';

@Component({
  selector: 'app-single-product',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './single-product.html',
})
export class SingleProduct implements OnInit {

  product!: Product; // אין צורך ב-null / תנאים

  constructor(
    private route: ActivatedRoute,
    private service: ProductService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = +params.get('id')!;

      this.service.getById(id).subscribe(product => {
        this.product = product;
        console.log('המוצר שהתקבל:', this.product);
      });
    });
  }

  back() {
    this.router.navigate(['/products', this.product.categoryName]);
  }

}
