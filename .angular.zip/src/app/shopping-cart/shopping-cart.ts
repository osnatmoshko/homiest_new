import { Component } from '@angular/core';
import { Product } from '../models/product';
import { ProductService } from '../services/product';
import { Router } from 'express';
import { identity } from 'rxjs';

@Component({
  selector: 'app-shopping-cart',
   standalone: true,
  imports: [],
  templateUrl: './shopping-cart.html',
})

export class ShoppingCart {
  showCart: Product[] = [];
    constructor( private service: ProductService) {}
  ngOnInit(): void {
  let json = localStorage.getItem('cart')

  console.log(json);
  
  }
}
