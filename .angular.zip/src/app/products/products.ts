import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../services/product';
import { Product } from '../models/product';
import { NgxSliderModule, Options } from '@angular-slider/ngx-slider';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, FormsModule, NgxSliderModule,RouterModule],
  templateUrl: './products.html',
})
export class Products implements OnInit {

  sliderOptions: Options = {
    floor: 0,
    ceil: 0,
    rightToLeft: true
  };

  allProduct: Product[] = [];
  filteredProducts: Product[] = [];

  minPrice!: number;
  maxPrice!: number;
  sortOrder: 'asc' | 'desc' | '' = '';

  constructor(private service: ProductService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const category = params.get('category')!;

      this.service.getByCategory(category).subscribe({
        next: (data) => {
          this.allProduct = data;
          console.log("Loaded:", this.allProduct);

          const prices = this.allProduct.map(p => p.price);

          this.sliderOptions = {
            floor: Math.min(...prices),
            ceil: Math.max(...prices),
            rightToLeft: true
          };

          this.minPrice = this.sliderOptions.floor!;
          this.maxPrice = this.sliderOptions.ceil!;

          this.applyFilters();
        },
        error: (err) => console.error('API failed:', err)
      });
    });
  }

  applyFilters(): void {
    let result = [...this.allProduct];

    result = result.filter(p =>
      p.price >= this.minPrice && p.price <= this.maxPrice
    );

    if (this.sortOrder === 'asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (this.sortOrder === 'desc') {
      result.sort((a, b) => b.price - a.price);
    }

    this.filteredProducts = result;
    console.log("Filtered:", result);
  }

  singleProduct(id: number){
    this.router.navigate(['/single-product', id]);
  }
  addCart(id: number){
    //  this.router.navigate(['/shopping-cart',id]);
    localStorage.setItem('cart', JSON.stringify(id));
  }
  backCatalog(){
  this.router.navigate(['/main-catalog']);
  }
}
